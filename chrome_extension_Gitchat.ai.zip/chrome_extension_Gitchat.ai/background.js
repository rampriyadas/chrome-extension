chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.type === "chat") {
		const userMessage = request.message;
		const readmeContent = request.readme;

		// Retrieve the API key from storage
		chrome.storage.sync.get("geminiApiKey", (data) => {
			const apiKey = data.geminiApiKey;

			if (!apiKey) {
				sendResponse({
					reply: "API key is not set in storage.",
				});
				return;
			}

			// Call Gemini's nano model API
			fetch("https://api.gemini.com/nano", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify({
					message: userMessage,
					context: readmeContent,
				}),
			})
				.then((response) => {
					if (!response.ok) {
						throw new Error(
							"Failed to communicate with Gemini API."
						);
					}
					return response.json();
				})
				.then((data) => {
					sendResponse({ reply: data.reply });
				})
				.catch((error) => {
					console.error("Error:", error);
					sendResponse({
						reply: "Error communicating with the Gemini model.",
					});
				});
		});

		return true; // Keeps the messaging channel open for asynchronous response.
	}
});
