// Function to check for README file and extract its content
function getReadmeContent() {
	const readmeElement = document.querySelector(
		"article.markdown-body.entry-content"
	);
	if (readmeElement) {
		return readmeElement.innerText;
	} else {
		return null;
	}
}

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.type === "getReadme") {
		const readmeContent = getReadmeContent();
		sendResponse({ readme: readmeContent });
	}
});
