document.getElementById("sendButton").addEventListener("click", () => {
	const input = document.getElementById("chatInput").value;

	// Get README content from the content script
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		chrome.tabs.sendMessage(
			tabs[0].id,
			{ type: "getReadme" },
			(response) => {
				let readmeContent = "No README available.";
				if (response && response.readme) {
					readmeContent = response.readme;
				}

				// Send the user message and README content to the background script
				chrome.runtime.sendMessage(
					{ type: "chat", message: input, readme: readmeContent },
					(response) => {
						if (chrome.runtime.lastError) {
							console.error(
								"Runtime error:",
								chrome.runtime.lastError.message
							);
							return;
						}

						const chatMessage = document.createElement("div");
						chatMessage.className = "chat-message user";
						chatMessage.textContent = input;
						document
							.getElementById("chat-output")
							.appendChild(chatMessage);

						const botMessage = document.createElement("div");
						botMessage.className = "chat-message";
						botMessage.textContent = response.reply;
						document
							.getElementById("chat-output")
							.appendChild(botMessage);

						document.getElementById("chatInput").value = "";
					}
				);
			}
		);
	});
});
